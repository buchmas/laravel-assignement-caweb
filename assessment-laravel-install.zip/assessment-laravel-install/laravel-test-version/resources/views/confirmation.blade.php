@extends('layouts/layout')

@section('title', 'List of Tasks')

@section('main')
	<div class="task-list">
	<p>Congratulations ! This task has been deleted.</p>
	</div>
@endsection